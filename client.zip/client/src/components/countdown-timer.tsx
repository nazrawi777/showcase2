import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Clock } from 'lucide-react';

interface CountdownTimerProps {
  slideId: number;
  durationSeconds: number;
  className?: string;
  themeColor?: string;
}

export function CountdownTimer({ slideId, durationSeconds, className, themeColor }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState(0);
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const storageKey = `timer_start_${slideId}`;
    
    const calculateTimeLeft = () => {
      let startTime = localStorage.getItem(storageKey);
      
      // First time seeing this slide - store start time now
      if (!startTime) {
        const now = Date.now();
        localStorage.setItem(storageKey, now.toString());
        startTime = now.toString();
      }
      
      const now = Date.now();
      const elapsedSeconds = Math.floor((now - parseInt(startTime)) / 1000);
      const remainingSeconds = Math.max(0, durationSeconds - elapsedSeconds);
      
      if (remainingSeconds <= 0) {
        setIsExpired(true);
        setTimeLeft(0);
        localStorage.setItem(`timer_expired_${slideId}`, 'true');
      } else {
        setIsExpired(false);
        setTimeLeft(remainingSeconds);
        localStorage.setItem(`timer_expired_${slideId}`, 'false');
      }
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, [slideId, durationSeconds]);

  const hours = Math.floor(timeLeft / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;

  const format = (num: number) => num.toString().padStart(2, '0');

  if (isExpired) {
    return (
      <div 
        className={cn(
          "inline-flex items-center gap-2 px-4 py-2 rounded-full font-mono text-sm font-bold tracking-widest backdrop-blur-md border border-white/10 shadow-lg",
          className
        )}
        style={{ 
          backgroundColor: `${themeColor}20`,
          borderColor: `${themeColor}60`,
          color: themeColor || '#fff',
          opacity: 0.5
        }}
      >
        <Clock className="w-4 h-4" />
        <span>Offer Ended</span>
      </div>
    );
  }

  return (
    <div 
      className={cn(
        "inline-flex items-center gap-2 px-4 py-2 rounded-full font-mono text-sm font-bold tracking-widest backdrop-blur-md border border-white/10 shadow-lg",
        className
      )}
      style={{ 
        backgroundColor: `${themeColor}20`,
        borderColor: `${themeColor}60`,
        color: themeColor || '#fff'
      }}
    >
      <Clock className="w-4 h-4" />
      <span>{format(hours)}:{format(minutes)}:{format(seconds)}</span>
    </div>
  );
}
