import { useState, useEffect, useRef, useCallback } from "react";
import { useSwipeable } from "react-swipeable";
import { ChevronLeft, ChevronRight, ShoppingBag, Zap, Bell } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Slide } from "@shared/schema";
import { CountdownTimer } from "./countdown-timer";
import { Button } from "./ui/button";

interface HeroSliderProps {
  slides: Slide[];
}

export function HeroSlider({ slides }: HeroSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [expiredSlides, setExpiredSlides] = useState<Set<number>>(new Set());
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const AUTOPLAY_DELAY = 5000;

  if (!slides || slides.length === 0) return null;

  const activeSlide = slides[currentIndex];
  const slideExpired = expiredSlides.has(activeSlide.id);
  
  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  }, [slides.length]);

  useEffect(() => {
    if (isPaused) return;
    timerRef.current = setInterval(nextSlide, AUTOPLAY_DELAY);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused, nextSlide]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") prevSlide();
      if (e.key === "ArrowRight") nextSlide();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [prevSlide, nextSlide]);

  const handlers = useSwipeable({
    onSwipedLeft: nextSlide,
    onSwipedRight: prevSlide,
    trackMouse: true
  });


  return (
    <div 
      className="relative w-full h-[85vh] min-h-[600px] overflow-hidden bg-background group"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onFocus={() => setIsPaused(true)}
      onBlur={() => setIsPaused(false)}
      {...handlers}
    >
      {slides.map((slide, index) => {
        const isActive = index === currentIndex;
        const slideExpired = expiredSlides.has(slide.id);
        
        return (
          <div
            key={slide.id}
            className={cn(
              "absolute inset-0 w-full h-full transition-opacity duration-700 ease-in-out",
              isActive ? "opacity-100 z-10" : "opacity-0 z-0 pointer-events-none"
            )}
          >
            <div className="absolute inset-0">
              <img 
                src={slide.imageUrl} 
                alt={slide.headline}
                className={cn(
                  "w-full h-full object-cover transition-transform duration-[6000ms] ease-out",
                  isActive ? "scale-105" : "scale-100"
                )}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/40 to-transparent sm:from-background/95 sm:via-background/70" />
            </div>

            <div className="relative z-20 container mx-auto h-full flex flex-col justify-center px-4 sm:px-6 lg:px-8">
              <div className="max-w-2xl space-y-8">
                
                <div 
                  className={cn(
                    "transition-all duration-700 delay-100 transform flex items-center gap-2 w-fit",
                    isActive ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                  )}
                >
                  <span 
                    className="flex items-center gap-2 px-3 py-1 rounded-md text-xs font-bold uppercase tracking-widest border border-white/20 backdrop-blur-md text-white shadow-[0_0_15px_rgba(0,0,0,0.5)]"
                    style={{ backgroundColor: slide.themeColor }}
                  >
                    <Zap className="w-3 h-3 fill-current" />
                    {slide.badgeText}
                  </span>
                  
                  <CountdownTimer 
                    slideId={slide.id}
                    durationSeconds={slide.timerDurationSeconds}
                    themeColor={slide.themeColor}
                    className="hidden sm:inline-flex"
                  />
                </div>

                <h1 
                  className={cn(
                    "text-5xl sm:text-7xl lg:text-8xl font-black text-white leading-[0.9] tracking-tighter uppercase drop-shadow-2xl transition-all duration-700 delay-200 transform",
                    isActive ? "translate-x-0 opacity-100" : "-translate-x-12 opacity-0",
                    slideExpired && "opacity-50"
                  )}
                  style={{ textShadow: '0 4px 30px rgba(0,0,0,0.5)' }}
                >
                  {slide.headline.split(' ').map((word, i) => (
                    <span key={i} className="block">
                      {i === 1 ? (
                         <span className="text-transparent bg-clip-text" style={{ 
                           backgroundImage: `linear-gradient(135deg, #fff 30%, ${slide.themeColor} 100%)` 
                         }}>
                           {word}
                         </span>
                      ) : word}
                    </span>
                  ))}
                </h1>

                <p 
                  className={cn(
                    "text-lg sm:text-xl text-white/80 font-medium max-w-lg leading-relaxed transition-all duration-700 delay-300 transform",
                    isActive ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                  )}
                >
                  {slide.subtext}
                </p>

                <div className={cn(
                    "sm:hidden transition-all duration-700 delay-300 transform",
                    isActive ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                  )}>
                  <CountdownTimer 
                    slideId={slide.id}
                    durationSeconds={slide.timerDurationSeconds}
                    themeColor={slide.themeColor}
                  />
                </div>

                <div 
                  className={cn(
                    "pt-4 transition-all duration-700 delay-500 transform",
                    isActive ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                  )}
                >
                  {slideExpired ? (
                    <button 
                      className="group relative h-14 px-8 rounded-none skew-x-[-10deg] border-0 text-white font-bold tracking-widest uppercase text-base overflow-hidden transition-transform active:scale-95 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] flex items-center gap-3 opacity-50 cursor-not-allowed"
                      style={{ backgroundColor: slide.themeColor }}
                      disabled
                      aria-label="Offer ended"
                      data-testid={`button-notify-${slide.id}`}
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500" />
                      <span className="flex items-center gap-3 skew-x-[10deg]">
                        <Bell className="w-5 h-5" />
                        Notify Me
                      </span>
                    </button>
                  ) : (
                    <a 
                      href={slide.ctaHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex"
                      aria-label={`${slide.buttonText}: ${slide.headline}`}
                      data-testid={`link-cta-${slide.id}`}
                    >
                      <button 
                        className="group relative h-14 px-8 rounded-none skew-x-[-10deg] border-0 text-white font-bold tracking-widest uppercase text-base overflow-hidden transition-transform active:scale-95 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] flex items-center gap-3"
                        style={{ backgroundColor: slide.themeColor }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500" />
                        <span className="flex items-center gap-3 skew-x-[10deg]">
                          <ShoppingBag className="w-5 h-5" />
                          {slide.buttonText}
                        </span>
                      </button>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })}

      <div className="absolute bottom-8 left-0 right-0 z-30 container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-end pointer-events-none">
        <div className="flex gap-3 pointer-events-auto">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={cn(
                "h-1.5 transition-all duration-500 rounded-full",
                idx === currentIndex ? "w-12 bg-white" : "w-6 bg-white/20 hover:bg-white/40"
              )}
              aria-label={`Go to slide ${idx + 1}`}
              data-testid={`button-indicator-${idx}`}
            />
          ))}
        </div>

        <div className="flex gap-2 pointer-events-auto">
          <button
            onClick={prevSlide}
            className="p-3 rounded-full border border-white/10 bg-black/20 backdrop-blur-md text-white hover:bg-white hover:text-black transition-all duration-300 active:scale-90"
            aria-label="Previous slide"
            data-testid="button-prev"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextSlide}
            className="p-3 rounded-full border border-white/10 bg-black/20 backdrop-blur-md text-white hover:bg-white hover:text-black transition-all duration-300 active:scale-90"
            aria-label="Next slide"
            data-testid="button-next"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-background to-transparent z-20 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-background to-transparent z-20 pointer-events-none" />
    </div>
  );
}
