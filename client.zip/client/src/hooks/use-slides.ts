import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertSlide } from "@shared/routes";

// GET /api/slides
export function useSlides() {
  return useQuery({
    queryKey: [api.slides.list.path],
    queryFn: async () => {
      const res = await fetch(api.slides.list.path, { credentials: "include" });
      if (!res.ok) throw new Error('Failed to fetch slides');
      return api.slides.list.responses[200].parse(await res.json());
    },
    // Keep stale time low for development updates, but cache effectively
    staleTime: 1000 * 60 * 5, 
  });
}

// POST /api/slides
export function useCreateSlide() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertSlide) => {
      const res = await fetch(api.slides.create.path, {
        method: api.slides.create.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error('Failed to create slide');
      return api.slides.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.slides.list.path] });
    },
  });
}
