import { HeroSlider } from "@/components/hero-slider";
import { useSlides, useCreateSlide } from "@/hooks/use-slides";
import { Loader2, Plus, Zap, AlertTriangle, ShieldCheck, Trophy, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { InsertSlide } from "@shared/schema";

// Fallback data if API is empty or fails initially (for polished first load experience)
const FALLBACK_SLIDES = (() => {
  const now = new Date();
  return [
    {
      id: 1,
      headline: "Cyber Street Collection",
      subtext: "Unleash your inner rebel with our latest drop inspired by Neo-Tokyo aesthetics. Limited edition gear available now.",
      buttonText: "Shop the Drop",
      ctaHref: "https://example.com/cyber-collection",
      badgeText: "New Arrival",
      endTime: new Date(now.getTime() + 48 * 60 * 60 * 1000),
      themeColor: "#8b5cf6",
      imageUrl: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=2070&auto=format&fit=crop",
      active: true
    },
    {
      id: 2,
      headline: "Neural Link Tech",
      subtext: "Experience the next generation of connectivity. Seamless integration for the digital nomad warrior.",
      buttonText: "Pre-Order Now",
      ctaHref: "https://example.com/neural-tech",
      badgeText: "Best Seller",
      endTime: new Date(now.getTime() + 24 * 60 * 60 * 1000),
      themeColor: "#ec4899",
      imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2070&auto=format&fit=crop",
      active: true
    },
    {
      id: 3,
      headline: "Midnight Runners",
      subtext: "Performance wear engineered for the concrete jungle. Reflective materials meet high-performance fabrics.",
      buttonText: "View Collection",
      ctaHref: "https://example.com/midnight-runners",
      badgeText: "Limited Time",
      endTime: new Date(now.getTime() + 72 * 60 * 60 * 1000),
      themeColor: "#f97316",
      imageUrl: "https://images.unsplash.com/photo-1515462277126-2dd0c162007a?q=80&w=1976&auto=format&fit=crop",
      active: true
    }
  ];
})();

export default function Home() {
  const { data: slides, isLoading, isError } = useSlides();
  
  // Decide what to show: API data, fallback, or loading
  const displaySlides = (slides && slides.length > 0) ? slides : FALLBACK_SLIDES;

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background text-primary">
        <Loader2 className="h-12 w-12 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary selection:text-white">
      {/* Navigation Bar (Mock) */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 bg-background/50 backdrop-blur-sm border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
            <Zap className="w-5 h-5 text-white fill-white" />
          </div>
          <span className="text-xl font-display font-black tracking-tighter uppercase">Nexus<span className="text-primary">Wear</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-8 font-mono text-sm uppercase tracking-widest text-muted-foreground">
          <a href="#" className="hover:text-white transition-colors">Drops</a>
          <a href="#" className="hover:text-white transition-colors">Men</a>
          <a href="#" className="hover:text-white transition-colors">Women</a>
          <a href="#" className="text-primary font-bold">Sale</a>
        </div>

        <div className="flex items-center gap-4">
          <CreateSlideDialog />
          <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10">
             <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-accent to-secondary" />
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="pt-0">
        <HeroSlider slides={displaySlides} />

        {/* Featured Section - Just to add depth to page */}
        <section className="container mx-auto px-6 py-24 space-y-12">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter mb-4">
                Why Choose <span className="text-gradient">Nexus</span>?
              </h2>
              <p className="text-muted-foreground max-w-xl text-lg">
                Engineered for the future, designed for today. Our gear is built to withstand the demands of the modern urban warrior.
              </p>
            </div>
            <Button variant="outline" className="hidden md:flex border-white/20 hover:bg-white/10">
              View All Features
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<ShieldCheck className="w-10 h-10 text-primary" />}
              title="Military Grade"
              description="Reinforced stitching and ballistic nylon materials ensure maximum durability in any environment."
            />
            <FeatureCard 
              icon={<Trophy className="w-10 h-10 text-secondary" />}
              title="Award Winning"
              description="Recognized by global design institutes for innovation in wearable technology and aesthetics."
            />
            <FeatureCard 
              icon={<Layers className="w-10 h-10 text-accent" />}
              title="Modular System"
              description="Compatible with our entire ecosystem of attachments, pouches, and tech integrations."
            />
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-white/10">
        <div className="container mx-auto px-6 text-center text-muted-foreground font-mono text-xs">
          <p>© 2024 NEXUS WEAR. ALL RIGHTS RESERVED.</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="group p-8 rounded-2xl bg-card border border-white/5 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-primary/10">
      <div className="mb-6 p-4 rounded-xl bg-background/50 w-fit group-hover:scale-110 transition-transform duration-300 ring-1 ring-white/10">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}

function CreateSlideDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const createSlide = useCreateSlide();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data: InsertSlide = {
      headline: formData.get("headline") as string,
      subtext: formData.get("subtext") as string,
      buttonText: formData.get("buttonText") as string,
      ctaHref: (formData.get("ctaHref") as string) || "#",
      badgeText: formData.get("badgeText") as string,
      themeColor: formData.get("themeColor") as string,
      imageUrl: formData.get("imageUrl") as string,
      timerDurationSeconds: 24 * 60 * 60, // Default 24 hours in seconds
      active: true,
    };

    createSlide.mutate(data, {
      onSuccess: () => {
        toast({ title: "Success", description: "Slide created successfully" });
        setOpen(false);
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to create slide", variant: "destructive" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-dashed border-white/30 hover:bg-white/5 hover:border-white">
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add Slide</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-card border-white/10">
        <DialogHeader>
          <DialogTitle>Add New Banner Slide</DialogTitle>
          <DialogDescription>
            Create a new promotional slide for the hero carousel.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="headline">Headline</Label>
            <Input id="headline" name="headline" placeholder="e.g. SUMMER SALE" required className="bg-background/50 border-white/10" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="subtext">Subtext</Label>
            <Input id="subtext" name="subtext" placeholder="Short description" required className="bg-background/50 border-white/10" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="buttonText">Button Text</Label>
              <Input id="buttonText" name="buttonText" placeholder="Shop Now" required className="bg-background/50 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="badgeText">Badge Text</Label>
              <Input id="badgeText" name="badgeText" placeholder="New" required className="bg-background/50 border-white/10" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="imageUrl">Image URL</Label>
            <Input id="imageUrl" name="imageUrl" placeholder="https://..." required className="bg-background/50 border-white/10" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ctaHref">CTA Link (URL)</Label>
            <Input id="ctaHref" name="ctaHref" placeholder="https://example.com" className="bg-background/50 border-white/10" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="themeColor">Theme Color (Hex)</Label>
            <div className="flex gap-2">
              <Input id="themeColor" name="themeColor" type="color" className="w-12 h-10 p-1 bg-background border-white/10" defaultValue="#8b5cf6" />
              <Input name="themeColorText" placeholder="#8b5cf6" className="flex-1 bg-background/50 border-white/10" defaultValue="#8b5cf6" readOnly />
            </div>
          </div>
          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createSlide.isPending}>
              {createSlide.isPending ? "Creating..." : "Create Slide"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
