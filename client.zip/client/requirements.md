## Packages
framer-motion | Essential for high-quality, smooth animations in React
react-swipeable | Touch gestures for the slider
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging tailwind classes without conflicts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
